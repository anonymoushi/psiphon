﻿本压缩文件是 赛风 3.95 版

关于它的介绍，请看俺的帖子：
如何翻墙？——写在Blogspot被封之后
http://program-think.blogspot.com/2009/05/how-to-break-through-gfw.html

由于上述地址已经被墙，可以通过Google Reader订阅俺的Blog，查看该帖子。
订阅地址是:  http://feeds2.feedburner.com/programthink


================================
编程随想

Email                 program.think@gmail.com
Twitter               https://twitter.com/programthink
Google+               https://plus.google.com/113559088971921339544/

Blog主站(需要翻墙)    http://program-think.blogspot.com/
RSS订阅地址           http://feeds2.feedburner.com/programthink

编程随想的收藏        https://github.com/programthink
